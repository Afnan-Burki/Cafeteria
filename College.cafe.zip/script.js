let order = [];
let total = 0;

// Add item to order
document.querySelectorAll('.add-to-cart').forEach(button => {
    button.addEventListener('click', function() {
        const itemElement = button.parentElement;
        const itemName = itemElement.getAttribute('data-name');
        const itemPrice = parseFloat(itemElement.getAttribute('data-price'));
        addToOrder(itemName, itemPrice);
    });
});

function addToOrder(item, price) {
    order.push({ item, price });
    total += price;
    updateOrderList();
}

// Update the order list display
function updateOrderList() {
    const orderList = document.getElementById('cart-items');
    const totalPrice = document.getElementById('total-price');
    orderList.innerHTML = '';

    order.forEach((orderItem, index) => {
        const li = document.createElement('li');
        li.textContent = `${orderItem.item} - PKR ${orderItem.price.toFixed(2)} `;
        
        const removeButton = document.createElement('button');
        removeButton.textContent = 'Remove';
        removeButton.onclick = () => removeFromOrder(index);
        li.appendChild(removeButton);

        orderList.appendChild(li);
    });

    totalPrice.textContent = `Total: PKR ${total.toFixed(2)}`;
    document.getElementById('cart-count').textContent = order.length; // Update cart count
}

document.getElementById('checkout').addEventListener('click', function() {
    const collegeNumber = document.getElementById('college-number').value;
    const houseSelect = document.getElementById('house-selection');
    const house = houseSelect.value;
    const locationSelect = document.getElementById('location').value;

    // Check if all fields are filled
    if (!collegeNumber || !house || !locationSelect) {
        alert("Please fill out all fields!");
        return;
    }

    if (order.length === 0) {
        alert("Your order is empty!");
        return;
    }

    let billContent = `<h2>Bill</h2>
<p>Visit the website of our top class educational  institution  known as PAF College Lower Topa . <p> <a href="http://www.topians.edu.pk" target="_blank"> PAF College Lower Topa</a>
                       <p style="text-align: right;">
                       <img src="pclt.png" alt="Logo" style="max-width: 200px;"/> 
                       </p>
                       <p>College: PAF College Lower Topa</p>
                       <p>College Cafeteria</p>
                       <p>College No: ${collegeNumber}</p>
                       <p>House: ${house}</p>
                       <p>Location: ${locationSelect}</p>
                       <ul>`;
    
    order.forEach(orderItem => {
        billContent += `<li>${orderItem.item} - PKR ${orderItem.price.toFixed(2)}</li>`;
    });

    billContent += `</ul>
                    <p>Total: PKR ${total.toFixed(2)}</p>
                    <p>Please pay your total amount.</p>
                    <p><strong>Note:</strong> Loan is not allowed.</p>`;
    
    const bill = document.getElementById('bill');
    bill.innerHTML = billContent;
    bill.style.cssText = 'background-color: skyblue; padding: 20px; border-radius: 10px; color: black; display: block;';

    order = [];
    total = 0;
    updateOrderList();
});

// Review submission
document.getElementById('review-form').addEventListener('submit', function(e) {
    e.preventDefault();
    const reviewText = document.getElementById('review-text').value;
    const reviewMessage = document.getElementById('review-message');

    const reviewDiv = document.createElement('div');
    reviewDiv.className = 'review-item';
    reviewDiv.textContent = reviewText;
    reviewMessage.appendChild(reviewDiv);
    reviewMessage.appendChild(document.createElement('br'));
    document.getElementById('review-text').value = '';
    alert("Thank you for your review!");
});

// Clear reviews
document.getElementById('clear-reviews').addEventListener('click', function() {
    document.getElementById('review-message').innerHTML = '';
});

// Modal functionality
window.onload = function() {
    const modal = document.getElementById('welcome-modal');
    const closeButton = document.querySelector('.close-button');
    const continueButton = document.getElementById('continue-button');

    modal.style.display = 'flex';

    closeButton.onclick = () => modal.style.display = 'none';
    continueButton.onclick = () => modal.style.display = 'none';

    window.onclick = event => {
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    };
};

function removeFromOrder(index) {
    total -= order[index].price;
    order.splice(index, 1);
    updateOrderList();
}
// New Order function
document.getElementById('new-order').addEventListener('click', function() {
    order = [];
    total = 0;

    document.getElementById('college-number').value = '';
    document.getElementById('house-selection').selectedIndex = 0; // Reset to default

    updateOrderList();
    const bill = document.getElementById('bill');
    bill.innerHTML = '';
    bill.style.display = 'none';
});
document.querySelector('button[type="submit"]').addEventListener('click', function(e) {
    e.preventDefault(); // Prevent the default form submission

    const collegeNumber = document.getElementById('college-number').value;
    const houseSelect = document.getElementById('house-selection').value;
    const locationSelect = document.getElementById('location').value;

    // Check if all fields are filled
    if (collegeNumber && houseSelect && locationSelect) {
        alert("Order placed successfully!");
    } else {
        alert("Please fill out all fields before placing your order.");
    }
});
